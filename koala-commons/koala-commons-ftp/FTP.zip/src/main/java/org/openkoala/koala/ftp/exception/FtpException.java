package org.openkoala.koala.ftp.exception;

public class FtpException extends Exception {
	public FtpException(String error) {
		super(error);
	}
}
